package com.example.feuerwehr_server

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
