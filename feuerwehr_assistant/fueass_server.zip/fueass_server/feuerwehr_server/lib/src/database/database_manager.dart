import 'package:postgres/postgres.dart';

class DatabaseManager {
  final PostgreSQLConnection _connection;
  final List<DatabaseMigration> _migrations;

  Future<void> runMigrations() async {
    await _ensureMigrationTableExists();
    final currentVersion = await _getCurrentVersion();
    
    for (final migration in _migrations.skip(currentVersion)) {
      await _connection.transaction((ctx) async {
        await ctx.query(migration.upScript);
        await ctx.query(
          'INSERT INTO _migrations (version) VALUES (@version)',
          substitutionValues: {'version': migration.version}
        );
      });
    }
  }

  Future<int> _getCurrentVersion() async {
    final result = await _connection.query(
      'SELECT MAX(version) FROM _migrations'
    );
    return result.first[0] as int? ?? 0;
  }
}